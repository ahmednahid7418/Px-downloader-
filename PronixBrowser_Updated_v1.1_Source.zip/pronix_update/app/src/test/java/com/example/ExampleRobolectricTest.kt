package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.pronix.download.DownloadUtils
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PronixRobolectricTest {

    @Test
    fun `read string from context matches Pronix Browser`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Pronix Browser", appName)
    }

    @Test
    fun `sanitizeFileName removes path traversal and dangerous characters`() {
        val maliciousInput = "../../etc/passwd.mp4"
        val sanitized = DownloadUtils.sanitizeFileName(maliciousInput)
        assertFalse(sanitized.contains(".."))
        assertFalse(sanitized.contains("/"))
        assertTrue(sanitized.endsWith(".mp4"))

        val specialChars = "video:test*?<>|\"name.mkv"
        val clean = DownloadUtils.sanitizeFileName(specialChars)
        assertFalse(clean.contains(":"))
        assertFalse(clean.contains("*"))
        assertFalse(clean.contains("?"))
        assertFalse(clean.contains("<"))
        assertFalse(clean.contains(">"))
        assertFalse(clean.contains("|"))
    }

    @Test
    fun `formatDuration formats correct time strings`() {
        assertEquals("00:00", DownloadUtils.formatDuration(0L))
        assertEquals("00:45", DownloadUtils.formatDuration(45000L))
        assertEquals("04:32", DownloadUtils.formatDuration((4 * 60 + 32) * 1000L))
        assertEquals("01:15:30", DownloadUtils.formatDuration((3600 + 15 * 60 + 30) * 1000L))
    }

    @Test
    fun `formatFileSize formats sizes accurately`() {
        assertEquals("500 B", DownloadUtils.formatFileSize(500L))
        assertEquals("10.0 KB", DownloadUtils.formatFileSize(10 * 1024L))
        assertEquals("25.5 MB", DownloadUtils.formatFileSize((25.5 * 1024 * 1024).toLong()))
        assertEquals("1.50 GB", DownloadUtils.formatFileSize((1.5 * 1024 * 1024 * 1024).toLong()))
    }

    @Test
    fun `isDirectMediaUrl identifies video formats`() {
        assertTrue(DownloadUtils.isDirectMediaUrl("https://example.com/movie.mp4"))
        assertTrue(DownloadUtils.isDirectMediaUrl("https://example.com/stream.m3u8"))
        assertTrue(DownloadUtils.isDirectMediaUrl("https://example.com/clip.webm?token=123"))
        assertFalse(DownloadUtils.isDirectMediaUrl("https://example.com/index.html"))
        assertFalse(DownloadUtils.isDirectMediaUrl("not_a_valid_url"))
    }
}
