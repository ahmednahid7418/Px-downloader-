package com.example.pronix.data.repository

import android.content.ContentUris
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.example.pronix.data.local.BookmarkDao
import com.example.pronix.data.local.DownloadDao
import com.example.pronix.data.local.HistoryDao
import com.example.pronix.data.local.TabDao
import com.example.pronix.data.local.VideoPlayHistoryDao
import com.example.pronix.data.model.*
import com.example.pronix.download.DownloadEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File

class BrowserRepository(
    private val tabDao: TabDao,
    private val bookmarkDao: BookmarkDao,
    private val historyDao: HistoryDao
) {
    val allTabs: Flow<List<BrowserTab>> = tabDao.getAllTabs()
    val allBookmarks: Flow<List<Bookmark>> = bookmarkDao.getAllBookmarks()
    val allHistory: Flow<List<HistoryItem>> = historyDao.getAllHistory()

    fun isBookmarked(url: String): Flow<Boolean> = bookmarkDao.isBookmarked(url)

    suspend fun createNewTab(url: String = "https://www.google.com", title: String = "New Tab"): Long {
        tabDao.deactivateAllTabs()
        val tab = BrowserTab(
            title = title,
            url = url,
            isActive = true,
            lastUpdated = System.currentTimeMillis()
        )
        return tabDao.insertTab(tab)
    }

    suspend fun switchTab(id: Long) {
        tabDao.deactivateAllTabs()
        tabDao.setActiveTab(id)
    }

    suspend fun updateTab(tab: BrowserTab) {
        tabDao.updateTab(tab)
    }

    suspend fun closeTab(id: Long) {
        tabDao.deleteTabById(id)
    }

    suspend fun toggleBookmark(title: String, url: String) {
        val bookmark = Bookmark(title = title.ifBlank { url }, url = url)
        bookmarkDao.insertBookmark(bookmark)
    }

    suspend fun removeBookmark(url: String) {
        bookmarkDao.deleteBookmarkByUrl(url)
    }

    suspend fun addHistory(title: String, url: String) {
        if (url.startsWith("http://") || url.startsWith("https://")) {
            historyDao.insertHistory(HistoryItem(title = title.ifBlank { url }, url = url))
        }
    }

    suspend fun clearHistory() {
        historyDao.clearAllHistory()
    }
}

class DownloadRepository(
    private val downloadDao: DownloadDao,
    private val downloadEngine: DownloadEngine
) {
    val allDownloads: Flow<List<DownloadItem>> = downloadDao.getAllDownloads()

    suspend fun startDownload(url: String, title: String, fileName: String? = null): Long {
        return downloadEngine.startDownload(url, title, fileName)
    }

    fun pauseDownload(id: Long) {
        downloadEngine.pauseDownload(id)
    }

    fun resumeDownload(id: Long) {
        downloadEngine.resumeDownload(id)
    }

    fun cancelDownload(id: Long) {
        downloadEngine.cancelDownload(id)
    }

    fun retryDownload(id: Long) {
        downloadEngine.retryDownload(id)
    }

    suspend fun deleteDownload(item: DownloadItem) {
        try {
            File(item.filePath).delete()
        } catch (_: Exception) {}
        downloadDao.deleteDownload(item)
    }
}

class MediaLibraryRepository(
    private val context: Context,
    private val downloadDao: DownloadDao,
    private val videoHistoryDao: VideoPlayHistoryDao
) {
    val playHistory: Flow<List<VideoPlayHistory>> = videoHistoryDao.getAllPlayHistory()
    val favoriteVideos: Flow<List<VideoPlayHistory>> = videoHistoryDao.getFavorites()
    val completedDownloads: Flow<List<DownloadItem>> = downloadDao.getDownloadsByStatus(DownloadStatus.COMPLETED)

    suspend fun savePlaybackProgress(uri: String, title: String, positionMs: Long, durationMs: Long) {
        val existing = videoHistoryDao.getPlayHistory(uri)
        val history = VideoPlayHistory(
            uriOrPath = uri,
            title = title,
            durationMs = durationMs,
            lastPositionMs = positionMs,
            lastPlayedAt = System.currentTimeMillis(),
            isFavorite = existing?.isFavorite ?: false,
            isLocal = existing?.isLocal ?: true
        )
        videoHistoryDao.savePlayHistory(history)
    }

    suspend fun toggleFavorite(uri: String, isFavorite: Boolean) {
        videoHistoryDao.setFavorite(uri, isFavorite)
    }

    suspend fun clearPlayHistory() {
        videoHistoryDao.clearPlayHistory()
    }

    suspend fun getSavedPosition(uri: String): Long {
        return videoHistoryDao.getPlayHistory(uri)?.lastPositionMs ?: 0L
    }

    /**
     * Query device video files using MediaStore API
     */
    suspend fun queryLocalVideos(): List<VideoPlayHistory> = withContext(Dispatchers.IO) {
        val videoList = mutableListOf<VideoPlayHistory>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.DATE_MODIFIED
        )
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        try {
            val cursor = context.contentResolver.query(
                collection,
                projection,
                null,
                null,
                "${MediaStore.Video.Media.DATE_MODIFIED} DESC"
            )
            cursor?.use {
                val idColumn = it.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameColumn = it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durationColumn = it.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)

                while (it.moveToNext()) {
                    val id = it.getLong(idColumn)
                    val name = it.getString(nameColumn) ?: "Video $id"
                    val duration = it.getLong(durationColumn)
                    val contentUri = ContentUris.withAppendedId(collection, id).toString()

                    videoList.add(
                        VideoPlayHistory(
                            uriOrPath = contentUri,
                            title = name,
                            durationMs = duration,
                            lastPositionMs = 0L,
                            lastPlayedAt = System.currentTimeMillis(),
                            isFavorite = false,
                            isLocal = true
                        )
                    )
                }
            }
        } catch (_: Exception) {}
        videoList
    }

    /**
     * Query device video files with resolution metadata for gallery display
     */
    suspend fun queryLocalGalleryVideos(): List<GalleryVideoItem> = withContext(Dispatchers.IO) {
        val videoList = mutableListOf<GalleryVideoItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_MODIFIED
        )
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        try {
            val cursor = context.contentResolver.query(
                collection,
                projection,
                null,
                null,
                "${MediaStore.Video.Media.DATE_MODIFIED} DESC"
            )
            cursor?.use {
                val idColumn = it.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameColumn = it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durationColumn = it.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val widthColumn = it.getColumnIndex(MediaStore.Video.Media.WIDTH)
                val heightColumn = it.getColumnIndex(MediaStore.Video.Media.HEIGHT)
                val sizeColumn = it.getColumnIndex(MediaStore.Video.Media.SIZE)

                while (it.moveToNext()) {
                    val id = it.getLong(idColumn)
                    val name = it.getString(nameColumn) ?: "Video $id"
                    val duration = it.getLong(durationColumn)
                    val width = if (widthColumn >= 0) it.getInt(widthColumn) else 0
                    val height = if (heightColumn >= 0) it.getInt(heightColumn) else 0
                    val size = if (sizeColumn >= 0) it.getLong(sizeColumn) else 0L

                    val quality = when {
                        (width >= 3840 || height >= 2160) -> "4K"
                        (width >= 1920 || height >= 1080) -> "1080p"
                        (width >= 1280 || height >= 720) -> "720p"
                        (width > 0 && height > 0) -> "HD"
                        else -> null
                    }

                    val contentUri = ContentUris.withAppendedId(collection, id).toString()

                    videoList.add(
                        GalleryVideoItem(
                            uriOrPath = contentUri,
                            title = name,
                            durationMs = duration,
                            qualityBadge = quality,
                            sizeBytes = size,
                            lastPositionMs = 0L,
                            isLocal = true
                        )
                    )
                }
            }
        } catch (_: Exception) {}
        videoList
    }
}

class SettingsRepository(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("pronix_prefs", Context.MODE_PRIVATE)

    private val _themeMode = MutableStateFlow(loadThemeMode())
    val themeMode = _themeMode.asStateFlow()

    private val _searchEngine = MutableStateFlow(loadSearchEngine())
    val searchEngine = _searchEngine.asStateFlow()

    private val _desktopMode = MutableStateFlow(prefs.getBoolean("desktop_mode", false))
    val desktopMode = _desktopMode.asStateFlow()

    private val _autoResume = MutableStateFlow(prefs.getBoolean("auto_resume", true))
    val autoResume = _autoResume.asStateFlow()

    private val _defaultSpeed = MutableStateFlow(prefs.getFloat("default_speed", 1.0f))
    val defaultSpeed = _defaultSpeed.asStateFlow()

    private fun loadThemeMode(): ThemeMode {
        val name = prefs.getString("theme_mode", ThemeMode.SYSTEM.name)
        return try {
            ThemeMode.valueOf(name ?: ThemeMode.SYSTEM.name)
        } catch (e: Exception) {
            ThemeMode.SYSTEM
        }
    }

    private fun loadSearchEngine(): SearchEngine {
        val name = prefs.getString("search_engine", SearchEngine.GOOGLE.name)
        return try {
            SearchEngine.valueOf(name ?: SearchEngine.GOOGLE.name)
        } catch (e: Exception) {
            SearchEngine.GOOGLE
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        prefs.edit().putString("theme_mode", mode.name).apply()
        _themeMode.value = mode
    }

    fun setSearchEngine(engine: SearchEngine) {
        prefs.edit().putString("search_engine", engine.name).apply()
        _searchEngine.value = engine
    }

    fun setDesktopMode(enabled: Boolean) {
        prefs.edit().putBoolean("desktop_mode", enabled).apply()
        _desktopMode.value = enabled
    }

    fun setAutoResume(enabled: Boolean) {
        prefs.edit().putBoolean("auto_resume", enabled).apply()
        _autoResume.value = enabled
    }

    fun setDefaultSpeed(speed: Float) {
        prefs.edit().putFloat("default_speed", speed).apply()
        _defaultSpeed.value = speed
    }
}
