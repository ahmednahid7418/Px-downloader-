package com.example.pronix.browser

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.view.ViewGroup
import android.webkit.*
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.pronix.data.model.BrowserTab
import com.example.pronix.data.model.DetectedMedia
import com.example.pronix.data.model.SearchEngine
import com.example.pronix.download.DownloadUtils
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.GlassBorderSubtle
import com.example.ui.theme.PrimaryCyan
import com.example.ui.theme.SecondaryViolet
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PronixBrowserScreen(
    currentTab: BrowserTab?,
    searchEngine: SearchEngine,
    isDesktopMode: Boolean,
    onTabUrlChanged: (tabId: Long, newUrl: String, newTitle: String) -> Unit,
    onOpenTabsSheet: () -> Unit,
    onOpenBookmarks: () -> Unit,
    onOpenDownloads: () -> Unit,
    onMediaDetectedForDownload: (DetectedMedia) -> Unit,
    onPlayDirectly: (url: String, title: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current

    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var urlInput by remember { mutableStateOf(currentTab?.url ?: searchEngine.homeUrl) }
    var pageTitle by remember { mutableStateOf(currentTab?.title ?: "Pronix Browser") }
    var pageProgress by remember { mutableStateOf(0) }
    var isLoading by remember { mutableStateOf(false) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }
    var isHttps by remember { mutableStateOf(false) }

    // Detected downloadable media on the current active page
    val detectedMediaList = remember { mutableStateListOf<DetectedMedia>() }
    var showDetectedMediaSheet by remember { mutableStateOf(false) }
    var sslErrorDialogInfo by remember { mutableStateOf<Pair<SslErrorHandler, String>?>(null) }

    // Pulsing radar animation for detected media badge
    val infiniteTransition = rememberInfiniteTransition(label = "radar")
    val radarScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    // Update urlInput when tab changes
    LaunchedEffect(currentTab?.id, currentTab?.url) {
        val target = currentTab?.url ?: searchEngine.homeUrl
        urlInput = target
        detectedMediaList.clear()
        webViewInstance?.loadUrl(target)
    }

    // Handle desktop mode toggle
    LaunchedEffect(isDesktopMode) {
        webViewInstance?.settings?.let { settings ->
            if (isDesktopMode) {
                settings.userAgentString = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            } else {
                settings.userAgentString = null // Default mobile UA
            }
            webViewInstance?.reload()
        }
    }

    fun navigateTo(input: String) {
        val trimmed = input.trim()
        val targetUrl = when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            trimmed.contains(".") && !trimmed.contains(" ") -> "https://$trimmed"
            else -> {
                val encoded = URLEncoder.encode(trimmed, StandardCharsets.UTF_8.name())
                String.format(searchEngine.searchUrlTemplate, encoded)
            }
        }
        urlInput = targetUrl
        focusManager.clearFocus()
        webViewInstance?.loadUrl(targetUrl)
    }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .statusBarsPadding()
            ) {
                // Address Bar Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if (webViewInstance?.canGoBack() == true) webViewInstance?.goBack()
                        },
                        enabled = canGoBack,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = if (canGoBack) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Futuristic Omnibar Capsule
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .clip(RoundedCornerShape(23.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(
                                BorderStroke(1.dp, if (isHttps) PrimaryCyan.copy(alpha = 0.4f) else GlassBorderSubtle),
                                RoundedCornerShape(23.dp)
                            )
                            .padding(horizontal = 12.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                if (isHttps) Icons.Default.Lock else Icons.Default.Public,
                                contentDescription = if (isHttps) "Secure connection" else "Not secure",
                                tint = if (isHttps) AccentGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            TextField(
                                value = urlInput,
                                onValueChange = { urlInput = it },
                                modifier = Modifier.weight(1f),
                                placeholder = {
                                    Text(
                                        "Search or type web address...",
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                    )
                                },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                                keyboardActions = KeyboardActions(onGo = { navigateTo(urlInput) }),
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent,
                                    focusedTextColor = MaterialTheme.colorScheme.onSurface,
                                    unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                                ),
                                textStyle = LocalTextStyle.current.copy(fontSize = 13.sp, fontWeight = FontWeight.Normal)
                            )

                            if (isLoading) {
                                IconButton(
                                    onClick = { webViewInstance?.stopLoading() },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Stop loading", modifier = Modifier.size(16.dp))
                                }
                            } else {
                                IconButton(
                                    onClick = { webViewInstance?.reload() },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Reload", modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    // Tabs Switcher Button
                    IconButton(
                        onClick = onOpenTabsSheet,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = PrimaryCyan.copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, PrimaryCyan.copy(alpha = 0.5f))
                        ) {
                            Text(
                                "1",
                                color = PrimaryCyan,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                            )
                        }
                    }

                    // Bookmarks & History
                    IconButton(
                        onClick = onOpenBookmarks,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Bookmarks, contentDescription = "Bookmarks", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(20.dp))
                    }
                }

                // High-Tech Animated Loading Progress Bar with Cyan Glow
                if (isLoading && pageProgress in 1..99) {
                    LinearProgressIndicator(
                        progress = { pageProgress / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp),
                        color = PrimaryCyan,
                        trackColor = Color.Transparent
                    )
                }
            }
        },
        floatingActionButton = {
            // Glowing Radar Video Sniffer Floating Action Button
            AnimatedVisibility(
                visible = detectedMediaList.isNotEmpty(),
                enter = scaleIn() + fadeIn(),
                exit = scaleOut() + fadeOut()
            ) {
                Box(contentAlignment = Alignment.Center) {
                    // Outer pulsing ring
                    Box(
                        modifier = Modifier
                            .size((56 * radarScale).dp)
                            .clip(CircleShape)
                            .background(PrimaryCyan.copy(alpha = 0.2f))
                    )

                    ExtendedFloatingActionButton(
                        onClick = { showDetectedMediaSheet = true },
                        containerColor = PrimaryCyan,
                        contentColor = Color.Black,
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.shadow(16.dp, RoundedCornerShape(24.dp), ambientColor = PrimaryCyan, spotColor = PrimaryCyan),
                        icon = {
                            BadgedBox(badge = {
                                Badge(
                                    containerColor = SecondaryViolet,
                                    contentColor = Color.White
                                ) {
                                    Text("${detectedMediaList.size}", fontWeight = FontWeight.Bold)
                                }
                            }) {
                                Icon(Icons.Default.Download, contentDescription = "Download detected video")
                            }
                        },
                        text = {
                            Text(
                                "Found Video (${detectedMediaList.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            databaseEnabled = true
                            allowFileAccess = false
                            allowContentAccess = false
                            mediaPlaybackRequiresUserGesture = false
                            useWideViewPort = true
                            loadWithOverviewMode = true
                            setSupportZoom(true)
                            builtInZoomControls = true
                            displayZoomControls = false
                            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                            cacheMode = WebSettings.LOAD_DEFAULT
                        }

                        addJavascriptInterface(object {
                            @JavascriptInterface
                            fun onVideoFound(videoSrc: String?, videoTitle: String?) {
                                if (!videoSrc.isNullOrBlank()) {
                                    val cleanUrl = videoSrc.trim()
                                    if (DownloadUtils.isValidUrl(cleanUrl)) {
                                        post {
                                            if (detectedMediaList.none { it.url == cleanUrl }) {
                                                detectedMediaList.add(
                                                    DetectedMedia(
                                                        url = cleanUrl,
                                                        title = videoTitle?.ifBlank { null } ?: pageTitle,
                                                        format = DownloadUtils.getExtension(cleanUrl).uppercase()
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }, "PronixDetector")

                        webViewClient = object : WebViewClient() {
                            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                super.onPageStarted(view, url, favicon)
                                isLoading = true
                                isHttps = url?.startsWith("https://") == true
                                url?.let { urlInput = it }
                                canGoBack = view?.canGoBack() == true
                                canGoForward = view?.canGoForward() == true
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                super.onPageFinished(view, url)
                                isLoading = false
                                canGoBack = view?.canGoBack() == true
                                canGoForward = view?.canGoForward() == true
                                val title = view?.title ?: "Web Page"
                                pageTitle = title
                                currentTab?.id?.let { tabId ->
                                    onTabUrlChanged(tabId, url ?: "", title)
                                }

                                val snifferScript = """
                                    (function() {
                                        var videos = document.getElementsByTagName('video');
                                        for (var i = 0; i < videos.length; i++) {
                                            var v = videos[i];
                                            var src = v.currentSrc || v.src;
                                            if (!src) {
                                                var sources = v.getElementsByTagName('source');
                                                if (sources.length > 0) src = sources[0].src;
                                            }
                                            if (src && src.startsWith('http')) {
                                                window.PronixDetector.onVideoFound(src, document.title);
                                            }
                                        }
                                    })();
                                """.trimIndent()
                                view?.evaluateJavascript(snifferScript, null)
                            }

                            override fun shouldInterceptRequest(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): WebResourceResponse? {
                                val reqUrl = request?.url?.toString() ?: ""
                                if (DownloadUtils.isDirectMediaUrl(reqUrl)) {
                                    post {
                                        if (detectedMediaList.none { it.url == reqUrl }) {
                                            detectedMediaList.add(
                                                DetectedMedia(
                                                    url = reqUrl,
                                                    title = pageTitle,
                                                    format = DownloadUtils.getExtension(reqUrl).uppercase()
                                                )
                                            )
                                        }
                                    }
                                }
                                return super.shouldInterceptRequest(view, request)
                            }

                            override fun onReceivedSslError(
                                view: WebView?,
                                handler: SslErrorHandler?,
                                error: SslError?
                            ) {
                                if (handler != null) {
                                    sslErrorDialogInfo = Pair(handler, error?.url ?: "Unknown URL")
                                }
                            }
                        }

                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                pageProgress = newProgress
                            }

                            override fun onReceivedTitle(view: WebView?, title: String?) {
                                if (!title.isNullOrBlank()) {
                                    pageTitle = title
                                }
                            }
                        }

                        setDownloadListener { url, userAgent, contentDisposition, mimetype, contentLength ->
                            val detected = DetectedMedia(
                                url = url,
                                title = URLUtil.guessFileName(url, contentDisposition, mimetype),
                                mimeType = mimetype ?: "video/mp4",
                                contentLength = contentLength,
                                format = DownloadUtils.getExtension(url).uppercase()
                            )
                            onMediaDetectedForDownload(detected)
                        }

                        webViewInstance = this
                        loadUrl(urlInput)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )

            // SSL Certificate Warning Dialog
            sslErrorDialogInfo?.let { (handler, failedUrl) ->
                AlertDialog(
                    onDismissRequest = {
                        handler.cancel()
                        sslErrorDialogInfo = null
                    },
                    icon = { Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFFEF4444)) },
                    title = { Text("Security Warning: SSL Untrusted", fontWeight = FontWeight.Bold) },
                    text = {
                        Text("The SSL certificate for $failedUrl could not be verified. Continuing may expose sensitive data. Pronix blocks untrusted certificates by default to protect your device.")
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            handler.cancel()
                            sslErrorDialogInfo = null
                        }) {
                            Text("Go Back (Safe)", fontWeight = FontWeight.Bold, color = PrimaryCyan)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = {
                            handler.proceed()
                            sslErrorDialogInfo = null
                        }) {
                            Text("Proceed (Unsafe)", color = Color(0xFFEF4444))
                        }
                    }
                )
            }

            // High-End Detected Media Bottom Sheet
            if (showDetectedMediaSheet) {
                ModalBottomSheet(
                    onDismissRequest = { showDetectedMediaSheet = false },
                    containerColor = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(PrimaryCyan.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PrimaryCyan, modifier = Modifier.size(18.dp))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    "Detected Media Streams (${detectedMediaList.size})",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            IconButton(onClick = { showDetectedMediaSheet = false }) {
                                Icon(Icons.Default.Close, contentDescription = "Close")
                            }
                        }

                        Text(
                            "Directly downloadable stream resources identified. DRM-protected content cannot be saved.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        detectedMediaList.forEach { media ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.dp, GlassBorderSubtle)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = PrimaryCyan.copy(alpha = 0.2f)
                                        ) {
                                            Text(
                                                media.format,
                                                color = PrimaryCyan,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            media.title,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        media.url,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )

                                    Spacer(modifier = Modifier.height(14.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedButton(
                                            onClick = {
                                                showDetectedMediaSheet = false
                                                onPlayDirectly(media.url, media.title)
                                            },
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.padding(end = 8.dp)
                                        ) {
                                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = PrimaryCyan, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Play Stream", color = PrimaryCyan, fontWeight = FontWeight.Bold)
                                        }

                                        Button(
                                            onClick = {
                                                showDetectedMediaSheet = false
                                                onMediaDetectedForDownload(media)
                                            },
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan)
                                        ) {
                                            Icon(Icons.Default.Download, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Save Video", color = Color.Black, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }
        }
    }
}
