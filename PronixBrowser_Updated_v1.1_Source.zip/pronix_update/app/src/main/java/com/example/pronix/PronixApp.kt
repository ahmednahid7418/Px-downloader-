package com.example.pronix

import android.app.Application
import com.example.pronix.data.local.PronixDatabase
import com.example.pronix.data.repository.BrowserRepository
import com.example.pronix.data.repository.DownloadRepository
import com.example.pronix.data.repository.MediaLibraryRepository
import com.example.pronix.data.repository.SettingsRepository
import com.example.pronix.download.DownloadEngine
import android.util.Log
import dev.ffmpegkit_maintained.ytdlp.compat.YoutubeDL

class PronixApp : Application() {

    lateinit var database: PronixDatabase
        private set

    lateinit var downloadEngine: DownloadEngine
        private set

    lateinit var browserRepository: BrowserRepository
        private set

    lateinit var downloadRepository: DownloadRepository
        private set

    lateinit var mediaLibraryRepository: MediaLibraryRepository
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    @Volatile var ytDlpReady: Boolean = false
        private set
    @Volatile var ytDlpInitError: String? = null
        private set

    companion object {
        lateinit var instance: PronixApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = PronixDatabase.getInstance(this)
        downloadEngine = DownloadEngine(this, database.downloadDao())

        browserRepository = BrowserRepository(
            database.tabDao(),
            database.bookmarkDao(),
            database.historyDao()
        )

        downloadRepository = DownloadRepository(
            database.downloadDao(),
            downloadEngine
        )

        mediaLibraryRepository = MediaLibraryRepository(
            this,
            database.downloadDao(),
            database.videoPlayHistoryDao()
        )

        settingsRepository = SettingsRepository(this)

        // Initialize the embedded yt-dlp runtime once. No API token or external app is required.
        try {
            YoutubeDL.getInstance().init(this)
            ytDlpReady = true
        } catch (e: Exception) {
            ytDlpInitError = e.localizedMessage ?: "Could not initialize yt-dlp runtime"
            Log.e("PronixApp", "yt-dlp initialization failed", e)
        }
    }
}
