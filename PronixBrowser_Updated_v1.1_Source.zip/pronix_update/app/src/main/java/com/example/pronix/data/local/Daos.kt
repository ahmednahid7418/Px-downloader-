package com.example.pronix.data.local

import androidx.room.*
import com.example.pronix.data.model.Bookmark
import com.example.pronix.data.model.BrowserTab
import com.example.pronix.data.model.DownloadItem
import com.example.pronix.data.model.DownloadStatus
import com.example.pronix.data.model.HistoryItem
import com.example.pronix.data.model.VideoPlayHistory
import kotlinx.coroutines.flow.Flow

@Dao
interface TabDao {
    @Query("SELECT * FROM browser_tabs ORDER BY lastUpdated DESC")
    fun getAllTabs(): Flow<List<BrowserTab>>

    @Query("SELECT * FROM browser_tabs WHERE isActive = 1 LIMIT 1")
    suspend fun getActiveTab(): BrowserTab?

    @Query("SELECT * FROM browser_tabs WHERE id = :id")
    suspend fun getTabById(id: Long): BrowserTab?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTab(tab: BrowserTab): Long

    @Update
    suspend fun updateTab(tab: BrowserTab)

    @Query("UPDATE browser_tabs SET isActive = 0")
    suspend fun deactivateAllTabs()

    @Query("UPDATE browser_tabs SET isActive = 1 WHERE id = :id")
    suspend fun setActiveTab(id: Long)

    @Delete
    suspend fun deleteTab(tab: BrowserTab)

    @Query("DELETE FROM browser_tabs WHERE id = :id")
    suspend fun deleteTabById(id: Long)

    @Query("DELETE FROM browser_tabs")
    suspend fun clearAllTabs()
}

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC")
    fun getAllBookmarks(): Flow<List<Bookmark>>

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE url = :url)")
    fun isBookmarked(url: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: Bookmark): Long

    @Query("DELETE FROM bookmarks WHERE url = :url")
    suspend fun deleteBookmarkByUrl(url: String)

    @Delete
    suspend fun deleteBookmark(bookmark: Bookmark)
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM browsing_history ORDER BY visitedAt DESC")
    fun getAllHistory(): Flow<List<HistoryItem>>

    @Query("SELECT * FROM browsing_history WHERE title LIKE '%' || :query || '%' OR url LIKE '%' || :query || '%' ORDER BY visitedAt DESC")
    fun searchHistory(query: String): Flow<List<HistoryItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(item: HistoryItem): Long

    @Delete
    suspend fun deleteHistory(item: HistoryItem)

    @Query("DELETE FROM browsing_history")
    suspend fun clearAllHistory()
}

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY createdAt DESC")
    fun getAllDownloads(): Flow<List<DownloadItem>>

    @Query("SELECT * FROM downloads WHERE status = :status ORDER BY createdAt DESC")
    fun getDownloadsByStatus(status: DownloadStatus): Flow<List<DownloadItem>>

    @Query("SELECT * FROM downloads WHERE id = :id")
    suspend fun getDownloadById(id: Long): DownloadItem?

    @Query("SELECT * FROM downloads WHERE id = :id")
    fun getDownloadFlow(id: Long): Flow<DownloadItem?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(item: DownloadItem): Long

    @Update
    suspend fun updateDownload(item: DownloadItem)

    @Query("UPDATE downloads SET status = :status, downloadedBytes = :downloaded, speedBps = :speed WHERE id = :id")
    suspend fun updateProgress(id: Long, downloaded: Long, speed: Long, status: DownloadStatus)

    @Query("UPDATE downloads SET status = :status, completedAt = :completedAt, downloadedBytes = totalBytes WHERE id = :id")
    suspend fun markCompleted(id: Long, completedAt: Long, status: DownloadStatus = DownloadStatus.COMPLETED)

    @Query("UPDATE downloads SET status = :status, errorMessage = :error WHERE id = :id")
    suspend fun markFailed(id: Long, error: String, status: DownloadStatus = DownloadStatus.FAILED)

    @Delete
    suspend fun deleteDownload(item: DownloadItem)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun deleteDownloadById(id: Long)
}

@Dao
interface VideoPlayHistoryDao {
    @Query("SELECT * FROM video_play_history ORDER BY lastPlayedAt DESC")
    fun getAllPlayHistory(): Flow<List<VideoPlayHistory>>

    @Query("SELECT * FROM video_play_history WHERE isFavorite = 1 ORDER BY lastPlayedAt DESC")
    fun getFavorites(): Flow<List<VideoPlayHistory>>

    @Query("SELECT * FROM video_play_history WHERE uriOrPath = :uri LIMIT 1")
    suspend fun getPlayHistory(uri: String): VideoPlayHistory?

    @Query("SELECT * FROM video_play_history WHERE uriOrPath = :uri LIMIT 1")
    fun getPlayHistoryFlow(uri: String): Flow<VideoPlayHistory?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePlayHistory(item: VideoPlayHistory)

    @Query("UPDATE video_play_history SET isFavorite = :isFavorite WHERE uriOrPath = :uri")
    suspend fun setFavorite(uri: String, isFavorite: Boolean)

    @Query("DELETE FROM video_play_history WHERE uriOrPath = :uri")
    suspend fun deletePlayHistory(uri: String)

    @Query("DELETE FROM video_play_history")
    suspend fun clearPlayHistory()
}
