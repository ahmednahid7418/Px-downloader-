package com.example.pronix.download

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.pronix.PronixApp
import com.example.pronix.data.local.DownloadDao
import com.example.pronix.data.model.DownloadItem
import com.example.pronix.data.model.DownloadStatus
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

class DownloadEngine(
    private val context: Context,
    private val downloadDao: DownloadDao
) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val activeJobs = ConcurrentHashMap<Long, Job>()
    private val pausedIds = ConcurrentHashMap.newKeySet<Long>()

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    fun getDownloadDirectory(): File {
        val dir = File(context.getExternalFilesDir(null), "PronixDownloads")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    suspend fun startDownload(url: String, title: String, preferredFileName: String? = null): Long {
        val sanitizedName = DownloadUtils.sanitizeFileName(
            preferredFileName ?: DownloadUtils.extractFileNameFromUrl(url)
        )
        val destinationFile = File(getDownloadDirectory(), sanitizedName)

        val item = DownloadItem(
            url = url,
            title = title.ifBlank { sanitizedName },
            fileName = destinationFile.name,
            filePath = destinationFile.absolutePath,
            totalBytes = -1L,
            downloadedBytes = 0L,
            status = DownloadStatus.DOWNLOADING,
            mimeType = DownloadUtils.getMimeTypeFromExtension(DownloadUtils.getExtension(destinationFile.name))
        )

        val id = downloadDao.insertDownload(item)
        startDownloadJob(id)
        startServiceIfRunning()
        return id
    }

    fun resumeDownload(id: Long) {
        pausedIds.remove(id)
        startDownloadJob(id)
        startServiceIfRunning()
    }

    fun pauseDownload(id: Long) {
        pausedIds.add(id)
        activeJobs[id]?.cancel()
        activeJobs.remove(id)
        scope.launch {
            val item = downloadDao.getDownloadById(id)
            if (item != null) {
                downloadDao.updateProgress(id, item.downloadedBytes, 0, DownloadStatus.PAUSED)
            }
            checkStopService()
        }
    }

    fun cancelDownload(id: Long) {
        pausedIds.remove(id)
        activeJobs[id]?.cancel()
        activeJobs.remove(id)
        scope.launch {
            val item = downloadDao.getDownloadById(id)
            if (item != null) {
                try {
                    File(item.filePath).delete()
                } catch (_: Exception) {}
                downloadDao.deleteDownloadById(id)
            }
            checkStopService()
        }
    }

    fun retryDownload(id: Long) {
        pausedIds.remove(id)
        startDownloadJob(id)
        startServiceIfRunning()
    }

    private fun startDownloadJob(id: Long) {
        activeJobs[id]?.cancel()
        val job = scope.launch {
            val item = downloadDao.getDownloadById(id) ?: return@launch
            val targetFile = File(item.filePath)
            var existingLength = if (targetFile.exists()) targetFile.length() else 0L

            // If file was already completed or corrupt, adjust
            if (existingLength > 0 && item.totalBytes > 0 && existingLength >= item.totalBytes) {
                existingLength = 0L
                targetFile.delete()
            }

            try {
                downloadDao.updateProgress(id, existingLength, 0, DownloadStatus.DOWNLOADING)

                val requestBuilder = Request.Builder()
                    .url(item.url)
                    .addHeader("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")

                if (existingLength > 0) {
                    requestBuilder.addHeader("Range", "bytes=$existingLength-")
                }

                val response = httpClient.newCall(requestBuilder.build()).execute()
                if (!response.isSuccessful && response.code != 206) {
                    throw Exception("HTTP ${response.code}: ${response.message}")
                }

                val body = response.body ?: throw Exception("Empty response body from server")
                val isRangeAccepted = (response.code == 206)
                if (!isRangeAccepted && existingLength > 0) {
                    // Server does not support range, start from 0
                    existingLength = 0L
                    targetFile.delete()
                }

                val contentLength = body.contentLength()
                val totalBytes = if (contentLength > 0) {
                    if (isRangeAccepted) existingLength + contentLength else contentLength
                } else item.totalBytes

                val updatedItem = item.copy(
                    totalBytes = totalBytes,
                    status = DownloadStatus.DOWNLOADING
                )
                downloadDao.updateDownload(updatedItem)

                val outputStream = if (isRangeAccepted && existingLength > 0) {
                    RandomAccessFile(targetFile, "rw").apply { seek(existingLength) }
                } else {
                    FileOutputStream(targetFile)
                }

                val inputStream = body.byteStream()
                val buffer = ByteArray(32 * 1024)
                var bytesRead: Int
                var currentDownloaded = existingLength
                var lastUpdateTime = System.currentTimeMillis()
                var bytesSinceLastUpdate = 0L

                try {
                    while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                        if (!isActive || pausedIds.contains(id)) {
                            break
                        }

                        if (outputStream is RandomAccessFile) {
                            outputStream.write(buffer, 0, bytesRead)
                        } else if (outputStream is FileOutputStream) {
                            outputStream.write(buffer, 0, bytesRead)
                        }

                        currentDownloaded += bytesRead
                        bytesSinceLastUpdate += bytesRead

                        val now = System.currentTimeMillis()
                        val elapsed = now - lastUpdateTime
                        if (elapsed >= 500) {
                            val speed = (bytesSinceLastUpdate * 1000) / elapsed
                            downloadDao.updateProgress(id, currentDownloaded, speed, DownloadStatus.DOWNLOADING)
                            lastUpdateTime = now
                            bytesSinceLastUpdate = 0L
                        }
                    }
                } finally {
                    try {
                        if (outputStream is RandomAccessFile) outputStream.close()
                        else if (outputStream is FileOutputStream) outputStream.close()
                        inputStream.close()
                    } catch (_: Exception) {}
                }

                if (pausedIds.contains(id)) {
                    downloadDao.updateProgress(id, currentDownloaded, 0, DownloadStatus.PAUSED)
                } else if (totalBytes > 0 && currentDownloaded >= totalBytes) {
                    downloadDao.markCompleted(id, System.currentTimeMillis())
                } else if (totalBytes <= 0 && currentDownloaded > 0) {
                    // Unknown length but stream completed
                    downloadDao.markCompleted(id, System.currentTimeMillis())
                }
            } catch (e: CancellationException) {
                // Cancelled or paused
            } catch (e: Exception) {
                downloadDao.markFailed(id, e.localizedMessage ?: "Download failed: connection interrupted")
            } finally {
                activeJobs.remove(id)
                checkStopService()
            }
        }
        activeJobs[id] = job
    }

    private fun startServiceIfRunning() {
        try {
            val intent = Intent(context, DownloadForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } catch (_: Exception) {}
    }

    private fun checkStopService() {
        if (activeJobs.isEmpty()) {
            try {
                val intent = Intent(context, DownloadForegroundService::class.java)
                context.stopService(intent)
            } catch (_: Exception) {}
        }
    }
}
