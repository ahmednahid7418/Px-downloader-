package com.example.pronix.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.example.pronix.data.model.Bookmark
import com.example.pronix.data.model.BrowserTab
import com.example.pronix.data.model.DownloadItem
import com.example.pronix.data.model.DownloadStatus
import com.example.pronix.data.model.HistoryItem
import com.example.pronix.data.model.VideoPlayHistory

class Converters {
    @TypeConverter
    fun fromDownloadStatus(status: DownloadStatus): String = status.name

    @TypeConverter
    fun toDownloadStatus(value: String): DownloadStatus = try {
        DownloadStatus.valueOf(value)
    } catch (e: Exception) {
        DownloadStatus.PENDING
    }
}

@Database(
    entities = [
        BrowserTab::class,
        Bookmark::class,
        HistoryItem::class,
        DownloadItem::class,
        VideoPlayHistory::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class PronixDatabase : RoomDatabase() {
    abstract fun tabDao(): TabDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun historyDao(): HistoryDao
    abstract fun downloadDao(): DownloadDao
    abstract fun videoPlayHistoryDao(): VideoPlayHistoryDao

    companion object {
        @Volatile
        private var INSTANCE: PronixDatabase? = null

        fun getInstance(context: Context): PronixDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PronixDatabase::class.java,
                    "pronix_browser.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
