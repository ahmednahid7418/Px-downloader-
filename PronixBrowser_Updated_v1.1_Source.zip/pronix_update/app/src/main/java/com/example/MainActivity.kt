package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.example.ui.theme.PrimaryCyan
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.pronix.PronixApp
import com.example.pronix.browser.PronixBrowserScreen
import com.example.pronix.data.model.*
import com.example.pronix.download.DownloadUtils
import com.example.pronix.player.PronixVideoPlayer
import com.example.pronix.ui.dialogs.*
import com.example.pronix.ui.downloads.DownloadsScreen
import com.example.pronix.ui.downloads.YtDlpScreen
import com.example.pronix.ui.home.HomeScreen
import com.example.pronix.ui.library.LibraryScreen
import com.example.pronix.ui.settings.SettingsScreen
import com.example.ui.theme.PronixTheme
import kotlinx.coroutines.launch

enum class AppDestination(val label: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    HOME("Home", Icons.Filled.Home, Icons.Outlined.Home),
    BROWSER("Browser", Icons.Filled.Language, Icons.Outlined.Language),
    DOWNLOADS("Downloads", Icons.Filled.Download, Icons.Outlined.Download),
    VIDEO_DL("Video DL", Icons.Filled.VideoLibrary, Icons.Outlined.VideoLibrary),
    LIBRARY("Library", Icons.Filled.VideoLibrary, Icons.Outlined.VideoLibrary),
    SETTINGS("Settings", Icons.Filled.Settings, Icons.Outlined.Settings)
}

data class PlayingVideoState(
    val uri: String,
    val title: String,
    val initialPositionMs: Long = 0L
)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as PronixApp

        setContent {
            val scope = rememberCoroutineScope()

            // Observe Repositories & Database States
            val themeMode by app.settingsRepository.themeMode.collectAsStateWithLifecycle()
            val searchEngine by app.settingsRepository.searchEngine.collectAsStateWithLifecycle()
            val desktopMode by app.settingsRepository.desktopMode.collectAsStateWithLifecycle()
            val autoResume by app.settingsRepository.autoResume.collectAsStateWithLifecycle()

            val tabs by app.browserRepository.allTabs.collectAsStateWithLifecycle(initialValue = emptyList())
            val bookmarks by app.browserRepository.allBookmarks.collectAsStateWithLifecycle(initialValue = emptyList())
            val history by app.browserRepository.allHistory.collectAsStateWithLifecycle(initialValue = emptyList())
            val downloads by app.downloadRepository.allDownloads.collectAsStateWithLifecycle(initialValue = emptyList())
            val playHistory by app.mediaLibraryRepository.playHistory.collectAsStateWithLifecycle(initialValue = emptyList())
            val completedDownloads by app.mediaLibraryRepository.completedDownloads.collectAsStateWithLifecycle(initialValue = emptyList())

            var localVideos by remember { mutableStateOf<List<GalleryVideoItem>>(emptyList()) }
            var isLoadingVideos by remember { mutableStateOf(true) }

            val galleryVideos = remember(completedDownloads, playHistory, localVideos) {
                val list = mutableListOf<GalleryVideoItem>()
                val seenUris = mutableSetOf<String>()

                completedDownloads.forEach { dl ->
                    if (seenUris.add(dl.filePath)) {
                        val quality = when {
                            dl.title.contains("4K", ignoreCase = true) -> "4K"
                            dl.title.contains("1080", ignoreCase = true) -> "1080p"
                            dl.title.contains("720", ignoreCase = true) -> "720p"
                            dl.title.contains("HD", ignoreCase = true) -> "HD"
                            else -> null
                        }
                        list.add(
                            GalleryVideoItem(
                                uriOrPath = dl.filePath,
                                title = dl.title,
                                durationMs = 0L,
                                qualityBadge = quality,
                                sizeBytes = dl.totalBytes.takeIf { it > 0 } ?: dl.downloadedBytes,
                                isLocal = true
                            )
                        )
                    }
                }

                localVideos.forEach { lv ->
                    if (seenUris.add(lv.uriOrPath)) {
                        list.add(lv)
                    }
                }

                playHistory.forEach { ph ->
                    if (seenUris.add(ph.uriOrPath)) {
                        val quality = when {
                            ph.title.contains("4K", ignoreCase = true) -> "4K"
                            ph.title.contains("1080", ignoreCase = true) -> "1080p"
                            ph.title.contains("720", ignoreCase = true) -> "720p"
                            ph.title.contains("HD", ignoreCase = true) -> "HD"
                            else -> null
                        }
                        list.add(
                            GalleryVideoItem(
                                uriOrPath = ph.uriOrPath,
                                title = ph.title,
                                durationMs = ph.durationMs,
                                qualityBadge = quality,
                                lastPositionMs = ph.lastPositionMs,
                                isLocal = ph.isLocal
                            )
                        )
                    }
                }

                list
            }

            // Active Tab
            val activeTab = remember(tabs) { tabs.find { it.isActive } ?: tabs.firstOrNull() }

            // Navigation Destination
            var currentDestination by remember { mutableStateOf(AppDestination.HOME) }

            // Active Playing Video State (non-null when full-screen player is opened)
            var activePlayingVideo by remember { mutableStateOf<PlayingVideoState?>(null) }

            // Modals and Dialogs
            var pendingDownloadMedia by remember { mutableStateOf<DetectedMedia?>(null) }
            var showDirectDownloadDialog by remember { mutableStateOf(false) }
            var showTabsSheet by remember { mutableStateOf(false) }
            var showBookmarksHistorySheet by remember { mutableStateOf(false) }

            // Request the media and notification permissions together so the local gallery is populated
            // only after Android has returned the permission result.
            val mediaPermissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) {
                scope.launch {
                    localVideos = app.mediaLibraryRepository.queryLocalGalleryVideos()
                    isLoadingVideos = false
                }
            }

            LaunchedEffect(Unit) {
                if (tabs.isEmpty()) {
                    app.browserRepository.createNewTab("https://www.google.com", "Google")
                }
                val requiredPermissions = mutableListOf<String>()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                        requiredPermissions += Manifest.permission.READ_MEDIA_VIDEO
                    }
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        requiredPermissions += Manifest.permission.POST_NOTIFICATIONS
                    }
                } else {
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        requiredPermissions += Manifest.permission.READ_EXTERNAL_STORAGE
                    }
                    if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P && ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        requiredPermissions += Manifest.permission.WRITE_EXTERNAL_STORAGE
                    }
                }
                if (requiredPermissions.isNotEmpty()) {
                    mediaPermissionLauncher.launch(requiredPermissions.toTypedArray())
                } else {
                    localVideos = app.mediaLibraryRepository.queryLocalGalleryVideos()
                    isLoadingVideos = false
                }
            }

            // Handle incoming VIEW intent (e.g., opened from link or external app)
            LaunchedEffect(intent) {
                intent?.data?.toString()?.let { incomingUrl ->
                    if (DownloadUtils.isDirectMediaUrl(incomingUrl)) {
                        activePlayingVideo = PlayingVideoState(
                            uri = incomingUrl,
                            title = DownloadUtils.extractFileNameFromUrl(incomingUrl)
                        )
                    } else {
                        app.browserRepository.createNewTab(incomingUrl, "Opened Link")
                        currentDestination = AppDestination.BROWSER
                    }
                }
                if (intent?.getStringExtra("OPEN_TAB") == "DOWNLOADS") {
                    currentDestination = AppDestination.DOWNLOADS
                }
            }

            // Global BackHandler
            BackHandler(enabled = activePlayingVideo != null || currentDestination != AppDestination.HOME) {
                if (activePlayingVideo != null) {
                    activePlayingVideo = null
                } else if (currentDestination != AppDestination.HOME) {
                    currentDestination = AppDestination.HOME
                }
            }

            val isDarkTheme = when (themeMode) {
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
                ThemeMode.SYSTEM -> androidx.compose.foundation.isSystemInDarkTheme()
            }

            PronixTheme(darkTheme = isDarkTheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Scaffold(
                        bottomBar = {
                            if (activePlayingVideo == null) {
                                NavigationBar(
                                    containerColor = MaterialTheme.colorScheme.surface,
                                    tonalElevation = 8.dp
                                ) {
                                    AppDestination.values().forEach { dest ->
                                        val isSelected = currentDestination == dest
                                        NavigationBarItem(
                                            selected = isSelected,
                                            onClick = { currentDestination = dest },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = Color.Black,
                                                selectedTextColor = PrimaryCyan,
                                                indicatorColor = PrimaryCyan,
                                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                            ),
                                            icon = {
                                                if (dest == AppDestination.DOWNLOADS) {
                                                    val activeCount = downloads.count { it.status == DownloadStatus.DOWNLOADING }
                                                    if (activeCount > 0) {
                                                        BadgedBox(badge = {
                                                            Badge { Text("$activeCount") }
                                                        }) {
                                                            Icon(
                                                                if (isSelected) dest.selectedIcon else dest.unselectedIcon,
                                                                contentDescription = dest.label
                                                            )
                                                        }
                                                    } else {
                                                        Icon(
                                                            if (isSelected) dest.selectedIcon else dest.unselectedIcon,
                                                            contentDescription = dest.label
                                                        )
                                                    }
                                                } else {
                                                    Icon(
                                                        if (isSelected) dest.selectedIcon else dest.unselectedIcon,
                                                        contentDescription = dest.label
                                                    )
                                                }
                                            },
                                            label = { Text(dest.label) }
                                        )
                                    }
                                }
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when (currentDestination) {
                                AppDestination.HOME -> {
                                    HomeScreen(
                                        videos = galleryVideos,
                                        isLoading = isLoadingVideos,
                                        onPlayVideo = { uri, title ->
                                            scope.launch {
                                                val savedPos = if (autoResume) app.mediaLibraryRepository.getSavedPosition(uri) else 0L
                                                activePlayingVideo = PlayingVideoState(uri, title, savedPos)
                                            }
                                        }
                                    )
                                }

                                AppDestination.BROWSER -> {
                                    PronixBrowserScreen(
                                        currentTab = activeTab,
                                        searchEngine = searchEngine,
                                        isDesktopMode = desktopMode,
                                        onTabUrlChanged = { tabId, newUrl, newTitle ->
                                            scope.launch {
                                                activeTab?.let { tab ->
                                                    app.browserRepository.updateTab(tab.copy(url = newUrl, title = newTitle))
                                                    app.browserRepository.addHistory(newTitle, newUrl)
                                                }
                                            }
                                        },
                                        onOpenTabsSheet = { showTabsSheet = true },
                                        onOpenBookmarks = { showBookmarksHistorySheet = true },
                                        onOpenDownloads = { currentDestination = AppDestination.DOWNLOADS },
                                        onMediaDetectedForDownload = { media ->
                                            pendingDownloadMedia = media
                                        },
                                        onPlayDirectly = { url, title ->
                                            scope.launch {
                                                val savedPos = if (autoResume) app.mediaLibraryRepository.getSavedPosition(url) else 0L
                                                activePlayingVideo = PlayingVideoState(url, title, savedPos)
                                            }
                                        }
                                    )
                                }

                                AppDestination.DOWNLOADS -> {
                                    DownloadsScreen(
                                        downloads = downloads,
                                        onPause = { app.downloadRepository.pauseDownload(it) },
                                        onResume = { app.downloadRepository.resumeDownload(it) },
                                        onCancel = { app.downloadRepository.cancelDownload(it) },
                                        onRetry = { app.downloadRepository.retryDownload(it) },
                                        onDelete = { scope.launch { app.downloadRepository.deleteDownload(it) } },
                                        onPlayCompleted = { filePath, title ->
                                            scope.launch {
                                                val savedPos = if (autoResume) app.mediaLibraryRepository.getSavedPosition(filePath) else 0L
                                                activePlayingVideo = PlayingVideoState(filePath, title, savedPos)
                                            }
                                        },
                                        onOpenDirectDownloadDialog = { showDirectDownloadDialog = true }
                                    )
                                }

                                AppDestination.VIDEO_DL -> {
                                    YtDlpScreen(
                                        onVideoSaved = {
                                            scope.launch { localVideos = app.mediaLibraryRepository.queryLocalGalleryVideos() }
                                        }
                                    )
                                }

                                AppDestination.LIBRARY -> {
                                    LibraryScreen(
                                        playHistory = playHistory,
                                        downloadedItems = completedDownloads,
                                        localDeviceVideos = localVideos.map {
                                            VideoPlayHistory(
                                                uriOrPath = it.uriOrPath,
                                                title = it.title,
                                                durationMs = it.durationMs,
                                                isLocal = true
                                            )
                                        },
                                        onPlayVideo = { uri, title ->
                                            scope.launch {
                                                val savedPos = if (autoResume) app.mediaLibraryRepository.getSavedPosition(uri) else 0L
                                                activePlayingVideo = PlayingVideoState(uri, title, savedPos)
                                            }
                                        },
                                        onToggleFavorite = { uri, isFav ->
                                            scope.launch { app.mediaLibraryRepository.toggleFavorite(uri, isFav) }
                                        },
                                        onDeleteHistory = { uri ->
                                            scope.launch { app.database.videoPlayHistoryDao().deletePlayHistory(uri) }
                                        },
                                        onClearAllHistory = {
                                            scope.launch { app.mediaLibraryRepository.clearPlayHistory() }
                                        }
                                    )
                                }

                                AppDestination.SETTINGS -> {
                                    SettingsScreen(
                                        currentTheme = themeMode,
                                        currentEngine = searchEngine,
                                        desktopMode = desktopMode,
                                        autoResume = autoResume,
                                        onThemeChanged = { app.settingsRepository.setThemeMode(it) },
                                        onSearchEngineChanged = { app.settingsRepository.setSearchEngine(it) },
                                        onDesktopModeChanged = { app.settingsRepository.setDesktopMode(it) },
                                        onAutoResumeChanged = { app.settingsRepository.setAutoResume(it) },
                                        onClearHistory = { scope.launch { app.browserRepository.clearHistory() } }
                                    )
                                }
                            }

                            // Fullscreen In-App Media3 Video Player
                            activePlayingVideo?.let { state ->
                                Box(modifier = Modifier.fillMaxSize()) {
                                    PronixVideoPlayer(
                                        videoUri = state.uri,
                                        videoTitle = state.title,
                                        initialPositionMs = state.initialPositionMs,
                                        onClose = { activePlayingVideo = null },
                                        onSaveProgress = { pos, dur ->
                                            scope.launch {
                                                app.mediaLibraryRepository.savePlaybackProgress(
                                                    uri = state.uri,
                                                    title = state.title,
                                                    positionMs = pos,
                                                    durationMs = dur
                                                )
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Download Confirm Dialog
                    pendingDownloadMedia?.let { media ->
                        DownloadConfirmDialog(
                            detectedMedia = media,
                            onConfirm = { url, title, fileName ->
                                scope.launch {
                                    app.downloadRepository.startDownload(url, title, fileName)
                                    pendingDownloadMedia = null
                                    currentDestination = AppDestination.DOWNLOADS
                                }
                            },
                            onDismiss = { pendingDownloadMedia = null }
                        )
                    }

                    // Direct URL Download Dialog
                    if (showDirectDownloadDialog) {
                        DirectUrlDownloadDialog(
                            onConfirm = { url, title ->
                                scope.launch {
                                    app.downloadRepository.startDownload(url, title)
                                    showDirectDownloadDialog = false
                                    currentDestination = AppDestination.DOWNLOADS
                                }
                            },
                            onDismiss = { showDirectDownloadDialog = false }
                        )
                    }

                    // Browser Tabs Sheet
                    if (showTabsSheet) {
                        TabsSheet(
                            tabs = tabs,
                            activeTabId = activeTab?.id,
                            onSelectTab = { tabId ->
                                scope.launch { app.browserRepository.switchTab(tabId) }
                            },
                            onCloseTab = { tabId ->
                                scope.launch { app.browserRepository.closeTab(tabId) }
                            },
                            onNewTab = {
                                scope.launch {
                                    app.browserRepository.createNewTab(searchEngine.homeUrl, "New Tab")
                                }
                            },
                            onDismiss = { showTabsSheet = false }
                        )
                    }

                    // Bookmarks and History Sheet
                    if (showBookmarksHistorySheet) {
                        BookmarksHistorySheet(
                            bookmarks = bookmarks,
                            history = history,
                            onNavigateUrl = { targetUrl ->
                                scope.launch {
                                    if (activeTab != null) {
                                        app.browserRepository.updateTab(activeTab.copy(url = targetUrl))
                                    } else {
                                        app.browserRepository.createNewTab(targetUrl, "Web")
                                    }
                                }
                            },
                            onDeleteBookmark = { bm ->
                                scope.launch { app.database.bookmarkDao().deleteBookmark(bm) }
                            },
                            onClearHistory = {
                                scope.launch { app.browserRepository.clearHistory() }
                            },
                            onDismiss = { showBookmarksHistorySheet = false }
                        )
                    }
                }
            }
        }
    }
}
