package com.example.pronix.ui.downloads

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.pronix.PronixApp
import dev.ffmpegkit_maintained.ytdlp.compat.YoutubeDL
import dev.ffmpegkit_maintained.ytdlp.compat.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream
import java.util.UUID

private data class QualityOption(val label: String, val format: String)

@Composable
fun YtDlpScreen(onVideoSaved: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val app = context.applicationContext as PronixApp
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf("") }
    var quality by remember { mutableStateOf("720p") }
    var isBusy by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var status by remember { mutableStateOf(if (app.ytDlpReady) "Ready — no API key required" else app.ytDlpInitError ?: "Preparing yt-dlp engine…") }
    var error by remember { mutableStateOf(false) }
    var processId by remember { mutableStateOf<String?>(null) }
    val options = listOf(
        QualityOption("Best", "best"),
        QualityOption("1080p", "best[height<=1080]/best"),
        QualityOption("720p", "best[height<=720]/best"),
        QualityOption("480p", "best[height<=480]/best"),
        QualityOption("360p", "best[height<=360]/best")
    )

    Column(
        modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Video Downloader", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Free yt-dlp engine • No API key • Downloads authorized, publicly accessible media", color = MaterialTheme.colorScheme.onSurfaceVariant)

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Link, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text("Video URL", fontWeight = FontWeight.SemiBold)
                }
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Paste video or supported page URL") },
                    placeholder = { Text("https://…") },
                    singleLine = true,
                    enabled = !isBusy
                )
                Text("Quality", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    options.forEach { option ->
                        FilterChip(
                            selected = quality == option.label,
                            onClick = { quality = option.label },
                            label = { Text(option.label) },
                            enabled = !isBusy
                        )
                    }
                }
                Button(
                    onClick = {
                        val input = url.trim()
                        if (!(input.startsWith("https://") || input.startsWith("http://"))) {
                            error = true; status = "Enter a valid http:// or https:// URL."; return@Button
                        }
                        if (!app.ytDlpReady) {
                            error = true; status = app.ytDlpInitError ?: "yt-dlp runtime is not ready. Reopen the app or check the build."; return@Button
                        }
                        isBusy = true; progress = 0f; error = false; status = "Starting extraction…"
                        val id = "pronix-" + UUID.randomUUID().toString()
                        processId = id
                        scope.launch {
                            try {
                                val saved = withContext(Dispatchers.IO) {
                                    downloadWithYtDlp(context, input, options.first { it.label == quality }.format, id) { value, line ->
                                        progress = value.coerceIn(0f, 100f)
                                        if (line.isNotBlank()) status = line.take(220)
                                    }
                                }
                                progress = 100f
                                status = if (saved.isNotEmpty()) "Saved to Movies/Pronix Browser and added to your phone gallery." else "Download finished, but no output file was found."
                                error = saved.isEmpty()
                                if (saved.isNotEmpty()) onVideoSaved()
                            } catch (e: Exception) {
                                error = true
                                status = e.localizedMessage ?: "Download failed. The website may be unsupported or may block extraction."
                            } finally {
                                isBusy = false; processId = null
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isBusy && app.ytDlpReady
                ) {
                    Icon(Icons.Default.Download, contentDescription = null)
                    Spacer(Modifier.height(0.dp))
                    Text(if (isBusy) " Downloading…" else "  Find & Download Video")
                }
                if (isBusy) {
                    Button(onClick = {
                        processId?.let { id ->
                            try { YoutubeDL.getInstance().destroyProcessById(id) } catch (_: Exception) {}
                        }
                        status = "Cancellation requested…"
                    }, modifier = Modifier.fillMaxWidth()) { Text("Cancel download") }
                    LinearProgressIndicator(progress = progress / 100f, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.height(18.dp))
                        Text("${progress.toInt()}%", style = MaterialTheme.typography.labelLarge)
                    }
                }
                Surface(color = if (error) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer, shape = MaterialTheme.shapes.medium) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (!error) Icon(Icons.Default.CheckCircle, contentDescription = null)
                        Text(status, color = if (error) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer)
                    }
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("How it works", fontWeight = FontWeight.Bold)
                Text("• No third-party API key or Termux required.")
                Text("• Completed files are copied to Movies/Pronix Browser using Android MediaStore, so they can appear in your gallery.")
                Text("• The built-in Library tab already scans phone videos and plays them with the app’s Media3 player.")
                Text("• Some websites may fail, and DRM or access-controlled content is not bypassed.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

private suspend fun downloadWithYtDlp(
    context: Context,
    url: String,
    format: String,
    processId: String,
    onProgress: (Float, String) -> Unit
): List<Uri> {
    val tempDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir, "yt-dlp-temp")
    if (!tempDir.exists() && !tempDir.mkdirs()) error("Could not create temporary download folder.")
    val startedAt = System.currentTimeMillis()
    val request = YoutubeDLRequest(url)
    request.addOption("--no-playlist")
    request.addOption("--newline")
    request.addOption("-f", format)
    request.addOption("-o", File(tempDir, "%(title).160B [%(id)s].%(ext)s").absolutePath)
    YoutubeDL.getInstance().execute(request, processId, { value, eta, line ->
        onProgress(value, line.ifBlank { if (eta >= 0) "Downloading • ETA ${eta}s" else "Downloading…" })
    })

    val completed = tempDir.listFiles()?.filter {
        it.isFile && it.lastModified() >= startedAt && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl")
    }?.sortedBy { it.lastModified() }.orEmpty()
    if (completed.isEmpty()) return emptyList()
    val published = mutableListOf<Uri>()
    for (file in completed) {
        val uri = publishVideoToMediaStore(context, file)
        if (uri != null) {
            published.add(uri)
            file.delete()
        }
    }
    tempDir.listFiles()?.filter { it.isFile && it.name.endsWith(".part") }?.forEach { it.delete() }
    return published
}

private fun publishVideoToMediaStore(context: Context, source: File): Uri? {
    val resolver = context.contentResolver
    val ext = source.extension.lowercase()
    val mime = when (ext) {
        "mp4", "m4v" -> "video/mp4"
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        "mov" -> "video/quicktime"
        "avi" -> "video/x-msvideo"
        "3gp" -> "video/3gpp"
        else -> "video/*"
    }
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, source.name)
        put(MediaStore.Video.Media.MIME_TYPE, mime)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Pronix Browser")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
    }
    val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
    } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    val uri = resolver.insert(collection, values) ?: return null
    try {
        resolver.openOutputStream(uri, "w")?.use { output: OutputStream ->
            FileInputStream(source).use { input -> input.copyTo(output) }
        } ?: error("Could not open gallery output stream.")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val ready = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            resolver.update(uri, ready, null, null)
        }
        return uri
    } catch (e: Exception) {
        try { resolver.delete(uri, null, null) } catch (_: Exception) {}
        throw e
    }
}
