package com.example.pronix.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "browser_tabs")
data class BrowserTab(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val url: String,
    val faviconUrl: String? = null,
    val isActive: Boolean = false,
    val isIncognito: Boolean = false,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "bookmarks")
data class Bookmark(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val url: String,
    val faviconUrl: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "browsing_history")
data class HistoryItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val url: String,
    val visitedAt: Long = System.currentTimeMillis()
)

enum class DownloadStatus {
    PENDING,
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    FAILED
}

@Entity(tableName = "downloads")
data class DownloadItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val url: String,
    val title: String,
    val fileName: String,
    val filePath: String,
    val totalBytes: Long = -1L,
    val downloadedBytes: Long = 0L,
    val status: DownloadStatus = DownloadStatus.PENDING,
    val mimeType: String = "video/mp4",
    val speedBps: Long = 0L,
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
) {
    val progressFraction: Float
        get() = if (totalBytes > 0) {
            (downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
        } else 0f

    val progressPercent: Int
        get() = (progressFraction * 100).toInt()
}

@Entity(tableName = "video_play_history")
data class VideoPlayHistory(
    @PrimaryKey
    val uriOrPath: String,
    val title: String,
    val durationMs: Long = 0L,
    val lastPositionMs: Long = 0L,
    val lastPlayedAt: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false,
    val isLocal: Boolean = true
) {
    val progressFraction: Float
        get() = if (durationMs > 0) {
            (lastPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
        } else 0f
}

data class DetectedMedia(
    val id: String = java.util.UUID.randomUUID().toString(),
    val url: String,
    val title: String,
    val mimeType: String = "video/mp4",
    val contentLength: Long = -1L,
    val format: String = "MP4",
    val quality: String? = null
)

enum class SearchEngine(val displayName: String, val searchUrlTemplate: String, val homeUrl: String) {
    GOOGLE("Google", "https://www.google.com/search?q=%s", "https://www.google.com"),
    DUCKDUCKGO("DuckDuckGo", "https://duckduckgo.com/?q=%s", "https://duckduckgo.com"),
    BING("Bing", "https://www.bing.com/search?q=%s", "https://www.bing.com"),
    BRAVE("Brave", "https://search.brave.com/search?q=%s", "https://search.brave.com"),
    ECOSIA("Ecosia", "https://www.ecosia.org/search?q=%s", "https://www.ecosia.org")
}

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

data class QuickLink(
    val title: String,
    val url: String,
    val iconHexColor: Long = 0xFF00E5FF
)

data class GalleryVideoItem(
    val uriOrPath: String,
    val title: String,
    val durationMs: Long = 0L,
    val qualityBadge: String? = null,
    val sizeBytes: Long = 0L,
    val lastPositionMs: Long = 0L,
    val isLocal: Boolean = true
)
