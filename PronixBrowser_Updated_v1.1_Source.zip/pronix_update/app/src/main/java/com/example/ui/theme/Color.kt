package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Premium Pronix Cyber / Flagship Palette
val PrimaryCyan = Color(0xFF00E5FF)
val PrimaryCyanVariant = Color(0xFF00B4D8)
val SecondaryViolet = Color(0xFF8B5CF6)
val SecondaryVioletDark = Color(0xFF6D28D9)
val ElectricPink = Color(0xFFFF2A85)
val AccentAmber = Color(0xFFFFB703)
val AccentRed = Color(0xFFEF4444)
val AccentGreen = Color(0xFF10B981)

// Dark Theme Surfaces
val DarkBackground = Color(0xFF080C16)
val DarkSurface = Color(0xFF0F1524)
val DarkSurfaceElevated = Color(0xFF161F33)
val DarkSurfaceCard = Color(0xFF1C2740)
val DarkSurfaceBorder = Color(0xFF283959)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkTextMuted = Color(0xFF64748B)

// Glassmorphic tokens
val GlassSurfaceDark = Color(0xCC0F1524)
val GlassSurfaceCard = Color(0x99161F33)
val GlassBorderDark = Color(0x3300E5FF)
val GlassBorderSubtle = Color(0x22FFFFFF)

// Light Theme Surfaces
val LightBackground = Color(0xFFF6F8FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFEDF2F7)
val LightSurfaceBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
val LightTextMuted = Color(0xFF94A3B8)

// Gradients
val CyberNeonGradient = Brush.horizontalGradient(
    colors = listOf(PrimaryCyan, SecondaryViolet)
)

val CyberGlowGradient = Brush.linearGradient(
    colors = listOf(PrimaryCyan, SecondaryViolet, ElectricPink)
)

val CardGlowBorder = Brush.linearGradient(
    colors = listOf(
        PrimaryCyan.copy(alpha = 0.6f),
        SecondaryViolet.copy(alpha = 0.3f),
        Color.Transparent
    )
)
