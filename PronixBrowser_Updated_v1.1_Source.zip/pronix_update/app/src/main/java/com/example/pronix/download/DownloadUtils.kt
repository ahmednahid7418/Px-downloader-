package com.example.pronix.download

import android.net.Uri
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.regex.Pattern

object DownloadUtils {

    private val VIDEO_EXTENSIONS = setOf(
        "mp4", "m4v", "mkv", "webm", "mov", "avi", "flv", "wmv", "3gp", "ts", "m3u8", "mpd"
    )

    private val AUDIO_EXTENSIONS = setOf(
        "mp3", "m4a", "aac", "ogg", "wav", "flac", "opus"
    )

    /**
     * Validates if a URL is a legitimate web address with http or https protocol.
     */
    fun isValidUrl(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val trimmed = url.trim()
        return try {
            val uri = Uri.parse(trimmed)
            val scheme = uri.scheme?.lowercase(Locale.ROOT)
            (scheme == "http" || scheme == "https") && !uri.host.isNullOrBlank()
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Sanitizes filenames to prevent directory traversal attacks (e.g. "../", null bytes, slashes).
     * Ensures filename is safe for file creation on Android storage.
     */
    fun sanitizeFileName(rawName: String?, fallbackExtension: String = "mp4"): String {
        if (rawName.isNullOrBlank()) {
            return "video_${System.currentTimeMillis()}.$fallbackExtension"
        }

        var clean = rawName.trim()
        // URL decode if percent-encoded
        try {
            clean = URLDecoder.decode(clean, StandardCharsets.UTF_8.name())
        } catch (_: Exception) {}

        // Remove path traversal and forbidden characters: \ / : * ? " < > | \0
        clean = clean.replace(Regex("[\\\\/:*?\"<>|\\x00-\\x1F]"), "_")
        clean = clean.replace(Regex("\\.{2,}"), "_") // Disallow multiple consecutive dots

        // Ensure not empty or starts with dot
        clean = clean.trim().trimStart('.').trimEnd('.')
        if (clean.isBlank()) {
            clean = "video_${System.currentTimeMillis()}"
        }

        // Truncate to reasonable length
        if (clean.length > 100) {
            val ext = getExtension(clean)
            val name = clean.substring(0, 90)
            clean = if (ext.isNotEmpty()) "$name.$ext" else name
        }

        // Ensure extension exists
        if (!clean.contains(".")) {
            clean = "$clean.$fallbackExtension"
        }

        return clean
    }

    /**
     * Extracts suggested filename from a URL or query parameters.
     */
    fun extractFileNameFromUrl(url: String): String {
        try {
            val uri = Uri.parse(url)
            val path = uri.path ?: ""
            val lastSegment = path.substringAfterLast('/', "")
            if (lastSegment.isNotBlank() && lastSegment.contains(".")) {
                return sanitizeFileName(lastSegment)
            }

            // Check query parameters for filename
            for (param in listOf("filename", "file", "title", "name")) {
                val candidate = uri.getQueryParameter(param)
                if (!candidate.isNullOrBlank()) {
                    return sanitizeFileName(candidate)
                }
            }

            val host = uri.host?.replace(".", "_") ?: "media"
            return sanitizeFileName("${host}_${System.currentTimeMillis()}.mp4")
        } catch (e: Exception) {
            return "video_${System.currentTimeMillis()}.mp4"
        }
    }

    /**
     * Detects if the given URL is a direct media/video stream.
     */
    fun isDirectMediaUrl(url: String): Boolean {
        if (!isValidUrl(url)) return false
        try {
            val uri = Uri.parse(url)
            val path = uri.path?.lowercase(Locale.ROOT) ?: ""
            val ext = path.substringAfterLast('.', "")
            if (VIDEO_EXTENSIONS.contains(ext) || AUDIO_EXTENSIONS.contains(ext)) {
                return true
            }

            // Also check for common streaming signatures
            if (path.contains("videoplayback") || path.contains(".m3u8") || path.contains(".mpd") || path.contains("/video/")) {
                return true
            }
        } catch (_: Exception) {}
        return false
    }

    fun getExtension(fileName: String): String {
        return fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
    }

    fun getMimeTypeFromExtension(ext: String): String {
        return when (ext.lowercase(Locale.ROOT)) {
            "mp4", "m4v" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "webm" -> "video/webm"
            "mov" -> "video/quicktime"
            "avi" -> "video/x-msvideo"
            "flv" -> "video/x-flv"
            "m3u8" -> "application/x-mpegURL"
            "mpd" -> "application/dash+xml"
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "aac" -> "audio/aac"
            "wav" -> "audio/wav"
            else -> "video/mp4"
        }
    }

    /**
     * Formats bytes into a human-readable string (KB, MB, GB).
     */
    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "Unknown size"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1.0 -> String.format(Locale.US, "%.2f GB", gb)
            mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
            kb >= 1.0 -> String.format(Locale.US, "%.1f KB", kb)
            else -> "$bytes B"
        }
    }

    /**
     * Formats download speed in bytes/sec to human readable format.
     */
    fun formatSpeed(bytesPerSec: Long): String {
        if (bytesPerSec <= 0) return "0 KB/s"
        val kb = bytesPerSec / 1024.0
        val mb = kb / 1024.0
        return when {
            mb >= 1.0 -> String.format(Locale.US, "%.2f MB/s", mb)
            else -> String.format(Locale.US, "%.1f KB/s", kb)
        }
    }

    /**
     * Formats milliseconds into duration string (HH:MM:SS or MM:SS).
     */
    fun formatDuration(durationMs: Long): String {
        if (durationMs <= 0) return "00:00"
        val totalSeconds = durationMs / 1000
        val seconds = totalSeconds % 60
        val minutes = (totalSeconds / 60) % 60
        val hours = totalSeconds / 3600
        return if (hours > 0) {
            String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }
}
