package com.example.pronix.ui.settings

import android.webkit.CookieManager
import android.webkit.WebView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pronix.data.model.SearchEngine
import com.example.pronix.data.model.ThemeMode
import com.example.ui.theme.PrimaryCyan

@Composable
fun SettingsScreen(
    currentTheme: ThemeMode,
    currentEngine: SearchEngine,
    desktopMode: Boolean,
    autoResume: Boolean,
    onThemeChanged: (ThemeMode) -> Unit,
    onSearchEngineChanged: (SearchEngine) -> Unit,
    onDesktopModeChanged: (Boolean) -> Unit,
    onAutoResumeChanged: (Boolean) -> Unit,
    onClearHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showThemeDialog by remember { mutableStateOf(false) }
    var showEngineDialog by remember { mutableStateOf(false) }
    var showClearDataDialog by remember { mutableStateOf(false) }
    var showDisclaimerDialog by remember { mutableStateOf(false) }
    var clearSuccessMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                Text(
                    "Settings",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Appearance section
            item {
                SettingsSectionHeader("Appearance & Display")
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column {
                        SettingsRow(
                            icon = Icons.Default.DarkMode,
                            title = "App Theme",
                            subtitle = currentTheme.name.lowercase().replaceFirstChar { it.uppercase() },
                            onClick = { showThemeDialog = true }
                        )
                    }
                }
            }

            // Web Browser section
            item {
                SettingsSectionHeader("Web Browser")
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column {
                        SettingsRow(
                            icon = Icons.Default.Search,
                            title = "Default Search Engine",
                            subtitle = currentEngine.displayName,
                            onClick = { showEngineDialog = true }
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        SettingsToggleRow(
                            icon = Icons.Default.DesktopWindows,
                            title = "Desktop Site by Default",
                            subtitle = "Request desktop version of web pages",
                            checked = desktopMode,
                            onCheckedChange = onDesktopModeChanged
                        )
                    }
                }
            }

            // Video Player section
            item {
                SettingsSectionHeader("Video Player")
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column {
                        SettingsToggleRow(
                            icon = Icons.Default.Replay,
                            title = "Auto-Resume Playback",
                            subtitle = "Resume video from last saved position",
                            checked = autoResume,
                            onCheckedChange = onAutoResumeChanged
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        SettingsRow(
                            icon = Icons.Default.AspectRatio,
                            title = "Default Aspect Ratio",
                            subtitle = "Fit to screen (customizable inside player)",
                            onClick = {}
                        )
                    }
                }
            }

            // Privacy & Clear Data section
            item {
                SettingsSectionHeader("Privacy & Storage")
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column {
                        SettingsRow(
                            icon = Icons.Default.DeleteOutline,
                            title = "Clear Browsing & Cache Data",
                            subtitle = "Clear history, cookies, and cached web files",
                            onClick = { showClearDataDialog = true },
                            tint = Color(0xFFEF4444)
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        SettingsRow(
                            icon = Icons.Default.Gavel,
                            title = "Copyright & DRM Policy",
                            subtitle = "Legal guidelines & media download disclaimer",
                            onClick = { showDisclaimerDialog = true }
                        )
                    }
                }
            }

            // App Info
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Pronix Browser v1.0.0",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "ExoPlayer Media3 • WebView Sandbox • OkHttp Engine",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
            }
        }

        // Theme Dialog
        if (showThemeDialog) {
            AlertDialog(
                onDismissRequest = { showThemeDialog = false },
                title = { Text("Choose Theme", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        ThemeMode.values().forEach { mode ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onThemeChanged(mode)
                                        showThemeDialog = false
                                    }
                                    .padding(vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    mode.name.lowercase().replaceFirstChar { it.uppercase() },
                                    fontWeight = if (currentTheme == mode) FontWeight.Bold else FontWeight.Normal,
                                    color = if (currentTheme == mode) PrimaryCyan else MaterialTheme.colorScheme.onSurface
                                )
                                if (currentTheme == mode) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = PrimaryCyan)
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showThemeDialog = false }) { Text("Close") }
                }
            )
        }

        // Search Engine Dialog
        if (showEngineDialog) {
            AlertDialog(
                onDismissRequest = { showEngineDialog = false },
                title = { Text("Default Search Engine", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        SearchEngine.values().forEach { engine ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onSearchEngineChanged(engine)
                                        showEngineDialog = false
                                    }
                                    .padding(vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    engine.displayName,
                                    fontWeight = if (currentEngine == engine) FontWeight.Bold else FontWeight.Normal,
                                    color = if (currentEngine == engine) PrimaryCyan else MaterialTheme.colorScheme.onSurface
                                )
                                if (currentEngine == engine) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = PrimaryCyan)
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showEngineDialog = false }) { Text("Close") }
                }
            )
        }

        // Clear Browsing Data Dialog
        if (showClearDataDialog) {
            var clearHistoryChecked by remember { mutableStateOf(true) }
            var clearCookiesChecked by remember { mutableStateOf(true) }
            var clearCacheChecked by remember { mutableStateOf(true) }

            AlertDialog(
                onDismissRequest = { showClearDataDialog = false },
                icon = { Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = Color(0xFFEF4444)) },
                title = { Text("Clear Browsing Data", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text(
                            "Select what you want to remove from Pronix Browser:",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = clearHistoryChecked, onCheckedChange = { clearHistoryChecked = it })
                            Text("Browsing history")
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = clearCookiesChecked, onCheckedChange = { clearCookiesChecked = it })
                            Text("Cookies & site data")
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = clearCacheChecked, onCheckedChange = { clearCacheChecked = it })
                            Text("Cached web files")
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (clearHistoryChecked) {
                                onClearHistory()
                            }
                            if (clearCookiesChecked) {
                                CookieManager.getInstance().removeAllCookies(null)
                                CookieManager.getInstance().flush()
                            }
                            if (clearCacheChecked) {
                                try {
                                    val dummyWv = WebView(context)
                                    dummyWv.clearCache(true)
                                    dummyWv.destroy()
                                } catch (_: Exception) {}
                            }
                            showClearDataDialog = false
                            clearSuccessMessage = "Browsing data cleared successfully!"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                    ) {
                        Text("Clear Data", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showClearDataDialog = false }) { Text("Cancel") }
                }
            )
        }

        // Copyright and DRM Disclaimer Dialog
        if (showDisclaimerDialog) {
            AlertDialog(
                onDismissRequest = { showDisclaimerDialog = false },
                icon = { Icon(Icons.Default.Security, contentDescription = null, tint = PrimaryCyan) },
                title = { Text("Copyright & DRM Notice", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text(
                            "Pronix Browser is built for user-authorized direct media downloading, public domain content, and educational or personal offline viewing of accessible media.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            "• Pronix Browser strictly does NOT bypass DRM, encryption, or copy-protection technologies.\n• Websites using proprietary encryption or intellectual property restrictions cannot and should not be downloaded.\n• Users are solely responsible for ensuring they possess rights or permissions to save media content in compliance with applicable copyright laws and platform terms of service.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showDisclaimerDialog = false }) { Text("Understood") }
                }
            )
        }

        // Clear Success Snackbar
        clearSuccessMessage?.let { msg ->
            LaunchedEffect(msg) {
                kotlinx.coroutines.delay(2500)
                clearSuccessMessage = null
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.BottomCenter
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF10B981)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        msg,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        color = PrimaryCyan,
        modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
    )
}

@Composable
fun SettingsRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    tint: Color = MaterialTheme.colorScheme.onSurface
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = tint)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
    }
}

@Composable
fun SettingsToggleRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = PrimaryCyan)
        )
    }
}
