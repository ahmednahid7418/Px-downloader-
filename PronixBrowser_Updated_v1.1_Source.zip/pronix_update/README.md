# Pronix Browser - Video Downloader, Player & Web Browser

Pronix Browser is a flagship-tier, native Android application built using Kotlin and Jetpack Compose that seamlessly integrates a modern multi-tab Web Browser, a Media3 ExoPlayer video playback engine, and a background Video Download Manager.

---

## 🌟 Key Features

### 1. Built-in Web Browser
- **Modern Address Bar:** URL detection, quick auto-complete, and integrated web search.
- **Search Engines:** Support for Google, DuckDuckGo, Bing, Brave, and Ecosia.
- **Media Sniffer Engine:** Real-time detection of HTML5 video sources and direct media streams (`.mp4`, `.m3u8`, `.webm`, `.mkv`, etc.). Displays a glowing one-tap download badge whenever media is detected.
- **Multi-Tab Manager:** Open, switch, and close multiple tabs with live previews.
- **Security & Safe Browsing:** Secure SSL error protection (never blindly bypasses certificate warnings) and zero JavaScript exposure to arbitrary sites.
- **Privacy Controls:** One-tap clearance for history, cookies, and cached files.
- **Desktop Mode:** Switch between mobile and desktop user agents on the fly.

### 2. Full-Featured Video Player
- **Engine:** Powered by Android Media3 ExoPlayer.
- **Format Support:** Local video storage, direct HTTP/HTTPS video streams, MP4, WebM, MKV, and HLS (`.m3u8`) streaming.
- **Intuitive Gestures:**
  - Swipe vertically on the **left side** of the screen to adjust **Brightness** (0–100%) with a live HUD indicator.
  - Swipe vertically on the **right side** of the screen to adjust **Volume** (0–100%) with a live HUD indicator.
  - **Double-tap left/right** to seek backward/forward 10 seconds with animated ripple cues.
- **Playback Controls:** Play, pause, seekbar with buffered indicator, variable playback speeds (0.5x, 0.75x, 1.0x, 1.25x, 1.5x, 2.0x), and aspect ratio modes (Fit, Stretch, Crop).
- **Picture-in-Picture (PiP):** Multitask while watching your videos in a floating window.
- **Auto-Resume:** Remembers your exact watch position for every played video.

### 3. Background Download Manager
- **Resumable Downloads:** Multi-threaded download engine with HTTP `Range` header support for pausing and resuming downloads without losing progress.
- **Real-Time Telemetry:** Live calculation of download speed (MB/s or KB/s), remaining percentage, and transferred byte sizes.
- **Foreground Service:** Runs an ongoing low-priority notification to ensure downloads finish even if the user locks the screen or minimizes the app.
- **Security & Path Traversal Protection:** File names are strictly sanitized to prevent path traversal (`../`) vulnerabilities and illegal filesystem characters.
- **Direct Link Downloader:** Dedicated input to paste any direct media link for instant background downloading.

### 4. Media Library & Storage
- **Categorized Hub:** Instant access to Continue Watching, Downloaded Media, Local Device Videos, and Starred Favorites.
- **Search & Filter:** Find any video by title or format.
- **Offline Playback:** Open any downloaded video straight into the built-in player.

---

## 🛠️ Architecture & Technologies

- **Language:** Kotlin 2.2.10
- **UI Framework:** Jetpack Compose with Material Design 3 (Edge-to-Edge)
- **Video Engine:** AndroidX Media3 ExoPlayer (`1.5.1`)
- **Web Engine:** Android WebView with custom `WebViewClient` and `WebChromeClient`
- **Networking:** OkHttp 4 for chunked streaming and HTTP Range resume
- **Local Persistence:** AndroidX Room Database with KSP (`2.7.0`)
- **Theme:** Dynamic Dark & Light theme modes with Cyber-flagship palette

---

## 🚀 Building & Running

### Requirements
- **Android Studio:** Ladybug (2024.2.1) or newer
- **JDK:** Version 17 or Version 21
- **Android SDK:** Compile SDK 36, Minimum SDK 24 (Android 7.0+)

### Step-by-Step Instructions

1. **Open the Project:**
   - Launch Android Studio.
   - Select **Open** and choose the `pronix-browser` root directory.
   - Wait for Gradle sync to complete automatically.

2. **Run Unit Tests:**
   Execute tests from Android Studio or via the terminal:
   ```bash
   gradle :app:testDebugUnitTest
   ```

3. **Build the APK:**
   ```bash
   gradle :app:assembleDebug
   ```
   The debug APK will be generated at:
   `app/build/outputs/apk/debug/app-debug.apk`

4. **Install on Device or Emulator:**
   Connect your Android device with USB debugging enabled, then click **Run 'app'** in Android Studio or run:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

---

## ⚖️ Copyright & Fair Use Notice

Pronix Browser is developed exclusively for saving user-authorized media, public domain works, and personal media content.
- Pronix Browser **does not** bypass DRM, encryption, or copy-protection schemes.
- Protected services (such as DRM-encrypted streams) cannot be downloaded.
- Users are responsible for complying with all applicable copyright laws and platform terms of service.


## Free yt-dlp integration (initial implementation)

- A new **Video DL** destination uses the free `yt-dlp-android` runtime (no API key, no Termux).
- Supports URL input and quality caps (Best, 1080p, 720p, 480p, 360p), progress feedback, and error messages.
- The engine downloads into app-private temporary storage, then publishes completed media to `Movies/Pronix Browser` through MediaStore so the existing Library/gallery can discover it.
- Uses `dev.ffmpegkit-maintained:yt-dlp-android:2.0.2` plus the compatibility shim; runtime bundle increases APK size substantially (approximately 60–80 MB for the yt-dlp library alone) and currently targets `arm64-v8a` and `x86_64`.
- This source update has not been compiled or run on a device in this environment. Gradle dependency resolution and Android Studio build/device testing are still required before calling the APK verified.
- Only download content you own or are authorized to save. DRM, paywall, and access-control bypass is not implemented.

## Build verification status

The source archive has been patched with the initial yt-dlp screen and gallery publication flow, and the manifest/static source checks passed. It has **not** been compiled or run on a physical Android device in this environment because Android SDK/Gradle build tooling is unavailable here. Do not treat this archive as a tested APK.
